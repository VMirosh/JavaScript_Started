let a = 10;
let b = 20;
let c = "hello";

 console.log(a == b);
 console.log(a < b);
 console.log(a > b);
 console.log(a === b);
 console.log(a !== b);
 console.log(b === c);
 console.log(b <= a);
 console.log(b >= c);
 console.log(a != 2);
 console.log(b !== c);
 