let a=1; b=2; c=3;
let result;
result= a+b+c;
console.log(typeof(result),result);
