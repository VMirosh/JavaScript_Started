alert("Hello world");
confirm("Are you ready?");
