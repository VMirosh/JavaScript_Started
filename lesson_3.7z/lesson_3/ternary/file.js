let x = 10;
let y = 0;

y = x > 5 ? y = 20 : y = 30;

// if (x > 5)
//     y = 20;
// else
//     y = 30;
console.log(y);
