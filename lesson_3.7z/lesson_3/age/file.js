let ageUser = Number(prompt("How old are you- ", 0));
if (ageUser >= 18) {
  alert("Welcome");
}
else {
  alert("The entrance is closed");
}

